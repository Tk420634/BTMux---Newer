
/*
   p.mech.tech.repairs.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Fri Jan 15 15:33:00 CET 1999 from mech.tech.repairs.c */

#ifndef _P_MECH_TECH_REPAIRS_H
#define _P_MECH_TECH_REPAIRS_H

/* mech.tech.repairs.c */
void tech_repairs(dbref player, MECH * mech, char *buffer);

#endif				/* _P_MECH_TECH_REPAIRS_H */
