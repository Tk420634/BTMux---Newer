
/*
   p.btspath.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Fri Jan 15 15:32:38 CET 1999 from btspath.c */

#ifndef _P_BTSPATH_H
#define _P_BTSPATH_H

/* btspath.c */
int MechTileCost(int fx, int fy, int tx, int ty);
int HoverTankTileCost(int fx, int fy, int tx, int ty);
int TrackedTankTileCost(int fx, int fy, int tx, int ty);

#endif				/* _P_BTSPATH_H */
