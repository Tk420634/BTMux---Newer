
/*
 * $Id: spath.c,v 1.1 2005/06/13 20:50:49 murrayma Exp $
 *
 * Last modified: Fri Dec 11 00:54:43 1998 fingon
 *
 */
