
/*
   p.spath.h

   Automatically created by protomaker (C) 1998 Markus Stenberg (fingon@iki.fi)
   Protomaker is actually only a wrapper script for cproto, but well.. I like
   fancy headers and stuff :)
   */

/* Generated at Mon Feb 22 14:59:39 CET 1999 from spath.c */

#ifndef _P_SPATH_H
#define _P_SPATH_H

/* spath.c */

#endif				/* _P_SPATH_H */
