#ifndef __NAMETAB_H__
#define __NAMETAB_H__
typedef struct name_table {
    char *name;
    int minlen;
    int perm;
    int flag;
} NAMETAB;
#endif

