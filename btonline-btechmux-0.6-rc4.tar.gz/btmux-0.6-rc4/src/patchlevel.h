
/* patchlevel.h - version information */

/* $Id: patchlevel.h,v 1.1 2005/06/13 20:50:47 murrayma Exp $ */

#include "copyright.h"

#define MINOR_REVNUM		"0-rc4"		/* Minor revision and/or rc number */
#define RELEASE_NAME        "Fly"

